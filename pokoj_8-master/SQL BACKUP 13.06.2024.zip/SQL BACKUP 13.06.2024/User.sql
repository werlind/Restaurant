USE [Restauracja]
GO

/****** Object:  User [Restauracja]    Script Date: 13.06.2024 19:08:17 ******/
CREATE USER [Restauracja] FOR LOGIN [Restauracja] WITH DEFAULT_SCHEMA=[dbo]
GO

