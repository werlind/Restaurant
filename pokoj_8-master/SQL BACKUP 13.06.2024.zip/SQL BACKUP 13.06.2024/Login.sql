USE [master]
GO

/* For security reasons the login is created disabled and with a random password. */
/****** Object:  Login [Restauracja]    Script Date: 13.06.2024 19:07:59 ******/
CREATE LOGIN [Restauracja] WITH PASSWORD=N'YfJbJe5+uDR7KK3i0LDvNBrcPc1EbT+j8GTPrVnn798=', DEFAULT_DATABASE=[Restauracja], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=ON
GO

ALTER LOGIN [Restauracja] DISABLE
GO

